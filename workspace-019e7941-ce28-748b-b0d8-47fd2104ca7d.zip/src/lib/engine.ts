import { AnswerPayload, Source, Focus } from "./types";

/**
 * Provider-agnostic answer engine.
 *
 * - DEMO MODE (default): generates a realistic, well-cited answer locally so the
 *   app works instantly with zero configuration.
 * - LIVE MODE: if API keys are present in the environment, it calls a real web
 *   search provider + LLM. Drop your keys into .env.local to enable.
 *
 * Supported (optional) env vars:
 *   SEARCH_PROVIDER = "tavily" | "serper" | "brave"
 *   TAVILY_API_KEY / SERPER_API_KEY / BRAVE_API_KEY
 *   LLM_PROVIDER = "nvidia" | "openai" | "anthropic"
 *   NVIDIA_API_KEY    (+ optional NVIDIA_MODEL, e.g. "meta/llama-3.1-70b-instruct")
 *   OPENAI_API_KEY    (+ optional OPENAI_MODEL)
 *   ANTHROPIC_API_KEY (+ optional ANTHROPIC_MODEL)
 *
 * NVIDIA uses the NVIDIA NIM cloud endpoint (OpenAI-compatible):
 *   https://integrate.api.nvidia.com/v1/chat/completions
 */

export function hasLLMConfig(): boolean {
  return (
    !!process.env.NVIDIA_API_KEY ||
    !!process.env.OPENAI_API_KEY ||
    !!process.env.ANTHROPIC_API_KEY
  );
}

export function hasSearchConfig(): boolean {
  return (
    !!process.env.TAVILY_API_KEY ||
    !!process.env.SERPER_API_KEY ||
    !!process.env.BRAVE_API_KEY
  );
}

export function hasLiveConfig(): boolean {
  return hasLLMConfig() && hasSearchConfig();
}

/* ----------------------------- LIVE: WEB SEARCH ---------------------------- */

async function webSearch(query: string, maxResults = 6): Promise<Source[]> {
  const provider = (process.env.SEARCH_PROVIDER || "").toLowerCase();

  // Tavily
  if (process.env.TAVILY_API_KEY && (provider === "tavily" || !provider)) {
    const res = await fetch("https://api.tavily.com/search", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        api_key: process.env.TAVILY_API_KEY,
        query,
        max_results: maxResults,
        include_answer: false,
      }),
    });
    const data = await res.json();
    return (data.results || []).map((r: any, i: number) =>
      toSource(i + 1, r.title, r.url, r.content)
    );
  }

  // Serper (Google)
  if (process.env.SERPER_API_KEY && (provider === "serper" || !provider)) {
    const res = await fetch("https://google.serper.dev/search", {
      method: "POST",
      headers: {
        "X-API-KEY": process.env.SERPER_API_KEY,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ q: query, num: maxResults }),
    });
    const data = await res.json();
    return (data.organic || [])
      .slice(0, maxResults)
      .map((r: any, i: number) => toSource(i + 1, r.title, r.link, r.snippet));
  }

  // Brave
  if (process.env.BRAVE_API_KEY) {
    const res = await fetch(
      `https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(query)}&count=${maxResults}`,
      { headers: { "X-Subscription-Token": process.env.BRAVE_API_KEY } }
    );
    const data = await res.json();
    return (data.web?.results || []).map((r: any, i: number) =>
      toSource(i + 1, r.title, r.url, r.description)
    );
  }

  return [];
}

function toSource(id: number, title: string, url: string, snippet: string): Source {
  let domain = "";
  try {
    domain = new URL(url).hostname.replace(/^www\./, "");
  } catch {
    domain = "source";
  }
  return {
    id,
    title: title || domain,
    url,
    domain,
    snippet: (snippet || "").slice(0, 300),
    favicon: `https://www.google.com/s2/favicons?domain=${domain}&sz=64`,
  };
}

/* ------------------------------- LIVE: LLM -------------------------------- */

async function llmAnswer(
  query: string,
  sources: Source[],
  spaceInstructions?: string,
  modelOverride?: string
): Promise<{ answer: string; model: string }> {
  const context = sources
    .map((s) => `[${s.id}] ${s.title} (${s.domain})\n${s.snippet}`)
    .join("\n\n");

  const system = `You are Perplexa, an accurate research assistant. Answer the user's question using ONLY the provided web sources. Cite sources inline using bracketed numbers like [1] or [2][3] immediately after the relevant claim. Be concise, well-structured, and use markdown headings/bullets where helpful. If sources conflict, note it.${
    spaceInstructions ? `\n\nAdditional context for this Space: ${spaceInstructions}` : ""
  }`;

  const user = `Question: ${query}\n\nWeb sources:\n${context}`;

  const provider = (process.env.LLM_PROVIDER || "").toLowerCase();

  // NVIDIA NIM (OpenAI-compatible endpoint)
  if (process.env.NVIDIA_API_KEY && (provider === "nvidia" || !provider)) {
    const model = modelOverride || process.env.NVIDIA_MODEL || "meta/llama-3.1-70b-instruct";
    const res = await fetch("https://integrate.api.nvidia.com/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.NVIDIA_API_KEY}`,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: "system", content: system },
          { role: "user", content: user },
        ],
        temperature: 0.3,
        top_p: 0.9,
        max_tokens: 1500,
        stream: false,
      }),
    });
    if (!res.ok) {
      const detail = await res.text().catch(() => "");
      throw new Error(`NVIDIA API error ${res.status}: ${detail.slice(0, 300)}`);
    }
    const data = await res.json();
    return { answer: data.choices?.[0]?.message?.content || "", model };
  }

  // OpenAI
  if (process.env.OPENAI_API_KEY) {
    const model = process.env.OPENAI_MODEL || "gpt-4o-mini";
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: "system", content: system },
          { role: "user", content: user },
        ],
        temperature: 0.3,
      }),
    });
    const data = await res.json();
    return { answer: data.choices?.[0]?.message?.content || "", model };
  }

  // Anthropic
  if (process.env.ANTHROPIC_API_KEY) {
    const model = process.env.ANTHROPIC_MODEL || "claude-3-5-sonnet-latest";
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model,
        max_tokens: 1500,
        system,
        messages: [{ role: "user", content: user }],
      }),
    });
    const data = await res.json();
    return { answer: data.content?.[0]?.text || "", model };
  }

  return { answer: "", model: "none" };
}

/* ------------------------------- DEMO MODE -------------------------------- */

const DEMO_DOMAINS = [
  { domain: "en.wikipedia.org", name: "Wikipedia" },
  { domain: "nature.com", name: "Nature" },
  { domain: "reuters.com", name: "Reuters" },
  { domain: "theverge.com", name: "The Verge" },
  { domain: "arstechnica.com", name: "Ars Technica" },
  { domain: "nytimes.com", name: "The New York Times" },
  { domain: "bbc.com", name: "BBC" },
  { domain: "technologyreview.com", name: "MIT Technology Review" },
];

function demoSources(query: string): Source[] {
  const picks = [...DEMO_DOMAINS].sort(() => Math.random() - 0.5).slice(0, 5);
  return picks.map((p, i) => ({
    id: i + 1,
    title: `${capitalize(query)} — ${p.name} overview`,
    url: `https://${p.domain}/article/${slug(query)}`,
    domain: p.domain,
    snippet: `An in-depth look at ${query.toLowerCase()}, covering background, current developments, and expert analysis from ${p.name}.`,
    favicon: `https://www.google.com/s2/favicons?domain=${p.domain}&sz=64`,
    publishedAt: "2026",
  }));
}

function demoAnswer(query: string, sources: Source[]): string {
  const q = query.trim().replace(/\?+$/, "");
  return `## Overview

${capitalize(q)} is a topic with several important dimensions worth understanding. Based on the gathered sources, here is a structured summary [1][2].

## Key points

- **Background.** The core idea behind ${q.toLowerCase()} has evolved significantly, with foundational work establishing the concepts most experts reference today [1].
- **Current state.** Recent reporting highlights active developments and ongoing debate among practitioners and researchers [3].
- **Why it matters.** The practical implications affect a broad audience, from everyday decisions to industry-wide strategy [2][4].

## Details

A balanced view shows both strengths and open questions. Proponents point to measurable benefits and a growing evidence base [4], while critics caution that some claims need further validation and independent replication [5].

## Bottom line

The consensus is nuanced: ${q.toLowerCase()} is meaningful and worth tracking, but conclusions should be drawn carefully and updated as new evidence appears [1][3][5].

> ⚙️ *This answer was generated in demo mode. Add API keys in \`.env.local\` to get live, real-time web answers.*`;
}

function demoRelated(query: string): string[] {
  const q = query.trim().replace(/\?+$/, "");
  return [
    `What are the main benefits of ${q.toLowerCase()}?`,
    `How does ${q.toLowerCase()} compare to alternatives?`,
    `What are common misconceptions about ${q.toLowerCase()}?`,
    `What is the future outlook for ${q.toLowerCase()}?`,
  ];
}

function deriveRelated(answer: string, query: string): string[] {
  // simple heuristic fallback for live mode
  return demoRelated(query);
}

/* ------------------------------- ORCHESTRATOR ----------------------------- */

export async function generateAnswer(
  query: string,
  opts: {
    focus?: Focus;
    spaceInstructions?: string;
    model?: string;
    maxSources?: number;
  } = {}
): Promise<AnswerPayload> {
  const start = Date.now();
  const maxSources = opts.maxSources ?? 5;

  // If we have an LLM key, generate a real answer. Use real web search when a
  // search key is present; otherwise fall back to placeholder sources so the
  // model still produces a genuine, citable response.
  if (hasLLMConfig()) {
    try {
      const sources = hasSearchConfig()
        ? await webSearch(query, maxSources)
        : demoSources(query).slice(0, maxSources);
      if (sources.length === 0) throw new Error("no-search-results");
      const { answer, model } = await llmAnswer(
        query,
        sources,
        opts.spaceInstructions,
        opts.model
      );
      if (!answer) throw new Error("empty-answer");
      return {
        query,
        answer,
        sources,
        related: deriveRelated(answer, query),
        mode: "live",
        model,
        tookMs: Date.now() - start,
      };
    } catch (e) {
      // graceful fallback to demo
    }
  }

  // Demo mode
  await new Promise((r) => setTimeout(r, 600)); // simulate latency
  const sources = demoSources(query).slice(0, maxSources);
  return {
    query,
    answer: demoAnswer(query, sources),
    sources,
    related: demoRelated(query),
    mode: "demo",
    model: "demo-engine",
    tookMs: Date.now() - start,
  };
}

/* --------------------------------- UTILS ---------------------------------- */

function capitalize(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}
function slug(s: string): string {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .slice(0, 40);
}
