"use client";
import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { Thread, Space, Message, AnswerPayload, Focus } from "./types";
import { defaultSpaces } from "@/data/spaces";
import { PLANS, planFor } from "./plans";

export class LimitError extends Error {
  constructor() {
    super("daily-limit");
    this.name = "LimitError";
  }
}

interface StoreState {
  threads: Thread[];
  spaces: Space[];
  theme: "light" | "dark";
  mode: "demo" | "live" | "unknown";
  llmLive: boolean;
  searchLive: boolean;
  isPro: boolean;
  usedToday: number;
  dailyLimit: number | null;
  remaining: number | null;
  setPro: (v: boolean) => void;
  toggleTheme: () => void;
  createThread: (firstQuery: string, spaceId?: string) => Promise<string>;
  askInThread: (threadId: string, query: string) => Promise<void>;
  getThread: (id: string) => Thread | undefined;
  deleteThread: (id: string) => void;
  addSpace: (s: Omit<Space, "id">) => void;
  deleteSpace: (id: string) => void;
}

const todayKey = () => new Date().toISOString().slice(0, 10);

const Ctx = createContext<StoreState | null>(null);

const uid = () => Math.random().toString(36).slice(2, 10);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [threads, setThreads] = useState<Thread[]>([]);
  const [spaces, setSpaces] = useState<Space[]>(defaultSpaces);
  const [theme, setTheme] = useState<"light" | "dark">("light");
  const [mode, setMode] = useState<"demo" | "live" | "unknown">("unknown");
  const [llmLive, setLlmLive] = useState(false);
  const [searchLive, setSearchLive] = useState(false);
  const [isPro, setIsPro] = useState(false);
  const [usedToday, setUsedToday] = useState(0);

  // hydrate
  useEffect(() => {
    try {
      const t = localStorage.getItem("perplexa.threads");
      if (t) setThreads(JSON.parse(t));
      const s = localStorage.getItem("perplexa.spaces");
      if (s) setSpaces(JSON.parse(s));
      const th = localStorage.getItem("perplexa.theme") as "light" | "dark" | null;
      if (th) setTheme(th);
      const pro = localStorage.getItem("perplexa.pro");
      if (pro === "1") setIsPro(true);
      // usage: { date, count }
      const usageRaw = localStorage.getItem("perplexa.usage");
      if (usageRaw) {
        const usage = JSON.parse(usageRaw);
        if (usage.date === todayKey()) setUsedToday(usage.count || 0);
        else setUsedToday(0);
      }
    } catch {}
    fetch("/api/search")
      .then((r) => r.json())
      .then((d) => {
        setMode(d.mode);
        setLlmLive(!!d.llm);
        setSearchLive(!!d.search);
      })
      .catch(() => setMode("demo"));
  }, []);

  // persist pro + usage
  useEffect(() => {
    try { localStorage.setItem("perplexa.pro", isPro ? "1" : "0"); } catch {}
  }, [isPro]);
  useEffect(() => {
    try {
      localStorage.setItem("perplexa.usage", JSON.stringify({ date: todayKey(), count: usedToday }));
    } catch {}
  }, [usedToday]);

  const dailyLimit = planFor(isPro).dailyLimit;
  const remaining = dailyLimit === null ? null : Math.max(0, dailyLimit - usedToday);

  const setPro = useCallback((v: boolean) => setIsPro(v), []);

  /** Throws LimitError if the free daily allowance is exhausted. */
  const checkAndCountUsage = useCallback(() => {
    const limit = planFor(isPro).dailyLimit;
    if (limit !== null && usedToday >= limit) {
      throw new LimitError();
    }
    setUsedToday((n) => n + 1);
  }, [isPro, usedToday]);

  // persist
  useEffect(() => {
    try { localStorage.setItem("perplexa.threads", JSON.stringify(threads)); } catch {}
  }, [threads]);
  useEffect(() => {
    try { localStorage.setItem("perplexa.spaces", JSON.stringify(spaces)); } catch {}
  }, [spaces]);
  useEffect(() => {
    try { localStorage.setItem("perplexa.theme", theme); } catch {}
    document.documentElement.classList.toggle("dark", theme === "dark");
  }, [theme]);

  const toggleTheme = useCallback(() => setTheme((t) => (t === "light" ? "dark" : "light")), []);

  const runQuery = useCallback(
    async (query: string, spaceId?: string): Promise<AnswerPayload> => {
      const space = spaceId ? spaces.find((s) => s.id === spaceId) : undefined;
      const res = await fetch("/api/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query, spaceInstructions: space?.instructions, pro: isPro }),
      });
      return res.json();
    },
    [spaces, isPro]
  );

  const setMsg = (threadId: string, msgId: string, patch: Partial<Message>) => {
    setThreads((prev) =>
      prev.map((t) =>
        t.id === threadId
          ? {
              ...t,
              updatedAt: Date.now(),
              messages: t.messages.map((m) => (m.id === msgId ? { ...m, ...patch } : m)),
            }
          : t
      )
    );
  };

  const staged = async (threadId: string, msgId: string) => {
    const stages: Message["status"][] = ["searching", "reading", "writing"];
    for (const s of stages) {
      setMsg(threadId, msgId, { status: s });
      await new Promise((r) => setTimeout(r, 450));
    }
  };

  const createThread = useCallback(
    async (firstQuery: string, spaceId?: string): Promise<string> => {
      checkAndCountUsage(); // throws LimitError when free allowance is used up
      const id = uid();
      const userMsg: Message = { id: uid(), role: "user", query: firstQuery };
      const aMsg: Message = { id: uid(), role: "assistant", status: "thinking", query: firstQuery };
      const thread: Thread = {
        id,
        title: firstQuery.slice(0, 60),
        createdAt: Date.now(),
        updatedAt: Date.now(),
        spaceId,
        messages: [userMsg, aMsg],
      };
      setThreads((prev) => [thread, ...prev]);

      staged(id, aMsg.id);
      try {
        const payload = await runQuery(firstQuery, spaceId);
        setMsg(id, aMsg.id, { status: "done", payload });
      } catch (e: any) {
        setMsg(id, aMsg.id, { status: "error", error: e?.message || "Something went wrong" });
      }
      return id;
    },
    [runQuery, checkAndCountUsage]
  );

  const askInThread = useCallback(
    async (threadId: string, query: string) => {
      checkAndCountUsage(); // throws LimitError when free allowance is used up
      const userMsg: Message = { id: uid(), role: "user", query };
      const aMsg: Message = { id: uid(), role: "assistant", status: "thinking", query };
      let spaceId: string | undefined;
      setThreads((prev) =>
        prev.map((t) => {
          if (t.id !== threadId) return t;
          spaceId = t.spaceId;
          return { ...t, updatedAt: Date.now(), messages: [...t.messages, userMsg, aMsg] };
        })
      );

      await staged(threadId, aMsg.id);
      try {
        const payload = await runQuery(query, spaceId);
        setMsg(threadId, aMsg.id, { status: "done", payload });
      } catch (e: any) {
        setMsg(threadId, aMsg.id, { status: "error", error: e?.message || "Something went wrong" });
      }
    },
    [runQuery, checkAndCountUsage]
  );

  const getThread = useCallback((id: string) => threads.find((t) => t.id === id), [threads]);
  const deleteThread = useCallback((id: string) => setThreads((p) => p.filter((t) => t.id !== id)), []);

  const addSpace = useCallback((s: Omit<Space, "id">) => {
    setSpaces((prev) => [...prev, { ...s, id: uid() }]);
  }, []);
  const deleteSpace = useCallback((id: string) => setSpaces((p) => p.filter((s) => s.id !== id)), []);

  return (
    <Ctx.Provider
      value={{
        threads,
        spaces,
        theme,
        mode,
        llmLive,
        searchLive,
        isPro,
        usedToday,
        dailyLimit,
        remaining,
        setPro,
        toggleTheme,
        createThread,
        askInThread,
        getThread,
        deleteThread,
        addSpace,
        deleteSpace,
      }}
    >
      {children}
    </Ctx.Provider>
  );
}

export function useStore() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
}
