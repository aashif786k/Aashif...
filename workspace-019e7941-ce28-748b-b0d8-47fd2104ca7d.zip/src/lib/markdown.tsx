"use client";
import React from "react";
import { Source } from "./types";

/**
 * Minimal, dependency-free markdown renderer tuned for answer text.
 * Supports: ## / ### headings, - bullet lists, 1. ordered lists,
 * **bold**, *italic*, `code`, > blockquotes, and [n] citation pills.
 */
export function renderMarkdown(text: string, sources: Source[], onCite?: (id: number) => void) {
  const lines = text.split("\n");
  const blocks: React.ReactNode[] = [];
  let listBuffer: { type: "ul" | "ol"; items: string[] } | null = null;
  let key = 0;

  const flushList = () => {
    if (!listBuffer) return;
    const items = listBuffer.items.map((it, i) => (
      <li key={i}>{inline(it, sources, onCite)}</li>
    ));
    blocks.push(
      listBuffer.type === "ul" ? (
        <ul key={key++}>{items}</ul>
      ) : (
        <ol key={key++}>{items}</ol>
      )
    );
    listBuffer = null;
  };

  for (const raw of lines) {
    const line = raw.replace(/\r$/, "");
    if (/^\s*$/.test(line)) {
      flushList();
      continue;
    }
    const ul = line.match(/^\s*[-*]\s+(.*)$/);
    const ol = line.match(/^\s*\d+\.\s+(.*)$/);
    const h2 = line.match(/^##\s+(.*)$/);
    const h3 = line.match(/^###\s+(.*)$/);
    const bq = line.match(/^>\s?(.*)$/);

    if (h2) {
      flushList();
      blocks.push(<h2 key={key++}>{inline(h2[1], sources, onCite)}</h2>);
    } else if (h3) {
      flushList();
      blocks.push(<h3 key={key++}>{inline(h3[1], sources, onCite)}</h3>);
    } else if (bq) {
      flushList();
      blocks.push(<blockquote key={key++}>{inline(bq[1], sources, onCite)}</blockquote>);
    } else if (ul) {
      if (!listBuffer || listBuffer.type !== "ul") {
        flushList();
        listBuffer = { type: "ul", items: [] };
      }
      listBuffer.items.push(ul[1]);
    } else if (ol) {
      if (!listBuffer || listBuffer.type !== "ol") {
        flushList();
        listBuffer = { type: "ol", items: [] };
      }
      listBuffer.items.push(ol[1]);
    } else {
      flushList();
      blocks.push(<p key={key++}>{inline(line, sources, onCite)}</p>);
    }
  }
  flushList();
  return blocks;
}

function inline(text: string, sources: Source[], onCite?: (id: number) => void): React.ReactNode[] {
  // Tokenize on citations [n], **bold**, *italic*, `code`
  const tokens: React.ReactNode[] = [];
  let remaining = text;
  let key = 0;
  const regex = /(\[\d+\](?:\[\d+\])*)|(\*\*[^*]+\*\*)|(\*[^*]+\*)|(`[^`]+`)/;

  while (remaining.length) {
    const m = remaining.match(regex);
    if (!m || m.index === undefined) {
      tokens.push(<React.Fragment key={key++}>{remaining}</React.Fragment>);
      break;
    }
    if (m.index > 0) {
      tokens.push(<React.Fragment key={key++}>{remaining.slice(0, m.index)}</React.Fragment>);
    }
    const tok = m[0];
    if (tok.startsWith("[")) {
      // one or more citations like [1][2]
      const nums = [...tok.matchAll(/\[(\d+)\]/g)].map((x) => parseInt(x[1], 10));
      nums.forEach((n) => {
        const src = sources.find((s) => s.id === n);
        tokens.push(
          <a
            key={key++}
            className="citation-pill"
            href={src?.url || "#"}
            target="_blank"
            rel="noreferrer"
            title={src ? `${src.title} — ${src.domain}` : `Source ${n}`}
            onClick={(e) => {
              if (onCite) {
                e.preventDefault();
                onCite(n);
              }
            }}
          >
            {n}
          </a>
        );
      });
    } else if (tok.startsWith("**")) {
      tokens.push(<strong key={key++}>{tok.slice(2, -2)}</strong>);
    } else if (tok.startsWith("*")) {
      tokens.push(<em key={key++}>{tok.slice(1, -1)}</em>);
    } else if (tok.startsWith("`")) {
      tokens.push(<code key={key++}>{tok.slice(1, -1)}</code>);
    }
    remaining = remaining.slice(m.index + tok.length);
  }
  return tokens;
}
