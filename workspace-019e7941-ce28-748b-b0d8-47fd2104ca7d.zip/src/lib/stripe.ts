import Stripe from "stripe";
import { PLANS } from "./plans";

/**
 * Stripe integration with graceful demo fallback.
 *
 * LIVE: set STRIPE_SECRET_KEY (and optionally STRIPE_PRICE_ID,
 *       STRIPE_WEBHOOK_SECRET, NEXT_PUBLIC_BASE_URL). Real Checkout sessions
 *       are created and webhooks verified.
 * DEMO: with no key, checkout returns a local "/upgrade/success?demo=1" URL so
 *       the whole upgrade flow is testable without any Stripe account.
 */

export function hasStripe(): boolean {
  return !!process.env.STRIPE_SECRET_KEY;
}

let _stripe: Stripe | null = null;
export function getStripe(): Stripe | null {
  if (!hasStripe()) return null;
  if (!_stripe) {
    _stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string, {
      apiVersion: "2024-06-20",
    });
  }
  return _stripe;
}

export function baseUrl(): string {
  return (
    process.env.NEXT_PUBLIC_BASE_URL ||
    process.env.VERCEL_URL ||
    "http://localhost:3000"
  ).replace(/\/$/, "");
}

/** Create a Checkout session (or a simulated URL in demo mode). */
export async function createCheckout(): Promise<{ url: string; demo: boolean }> {
  const stripe = getStripe();
  const pro = PLANS.pro;

  if (!stripe) {
    // Demo mode: skip straight to the success page with a demo flag.
    return { url: `${baseUrl()}/upgrade/success?demo=1`, demo: true };
  }

  // Use a configured price, or create an inline price for the Pro plan.
  const line_items: Stripe.Checkout.SessionCreateParams.LineItem[] = pro.priceId
    ? [{ price: pro.priceId, quantity: 1 }]
    : [
        {
          quantity: 1,
          price_data: {
            currency: "usd",
            recurring: { interval: "month" },
            unit_amount: pro.priceMonthly * 100,
            product_data: {
              name: "Perplexa Pro",
              description: pro.tagline,
            },
          },
        },
      ];

  const session = await stripe.checkout.sessions.create({
    mode: "subscription",
    line_items,
    success_url: `${baseUrl()}/upgrade/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${baseUrl()}/pricing?canceled=1`,
    allow_promotion_codes: true,
  });

  return { url: session.url || `${baseUrl()}/pricing`, demo: false };
}

/** Verify a completed checkout session by id (live mode). */
export async function verifySession(sessionId: string): Promise<boolean> {
  const stripe = getStripe();
  if (!stripe) return false;
  try {
    const session = await stripe.checkout.sessions.retrieve(sessionId);
    return session.payment_status === "paid" || session.status === "complete";
  } catch {
    return false;
  }
}
