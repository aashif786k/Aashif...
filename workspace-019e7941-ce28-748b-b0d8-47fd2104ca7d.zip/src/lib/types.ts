// Shared types for the Perplexa app

export interface Source {
  id: number;
  title: string;
  url: string;
  domain: string;
  snippet: string;
  favicon?: string;
  publishedAt?: string;
}

export interface RelatedQuestion {
  text: string;
}

export interface AnswerPayload {
  query: string;
  answer: string; // markdown-ish text with [n] citation markers
  sources: Source[];
  related: string[];
  images?: { url: string; title: string; source: string }[];
  mode: "demo" | "live";
  model?: string;
  tookMs?: number;
  plan?: "free" | "pro";
}

export interface Message {
  id: string;
  role: "user" | "assistant";
  query?: string;
  payload?: AnswerPayload;
  status?: "thinking" | "searching" | "reading" | "writing" | "done" | "error";
  error?: string;
}

export interface Thread {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  spaceId?: string;
  messages: Message[];
}

export interface Space {
  id: string;
  name: string;
  emoji: string;
  description: string;
  instructions?: string;
  color: string;
}

export type Focus = "all" | "academic" | "writing" | "video" | "social" | "finance";

export interface DiscoverItem {
  id: string;
  category: string;
  title: string;
  summary: string;
  image: string;
  source: string;
  readMins: number;
}
