// Subscription tiers for Perplexa

export type Plan = "free" | "pro";

export interface PlanConfig {
  id: Plan;
  name: string;
  tagline: string;
  priceMonthly: number; // USD
  priceId?: string; // Stripe price id (live mode)
  features: { label: string; included: boolean }[];
  /** NVIDIA model used for this tier */
  model: string;
  /** Number of web sources fetched per query */
  maxSources: number;
  /** Daily query allowance (null = unlimited) */
  dailyLimit: number | null;
}

// The premium model is more capable; the free model is fast and cheap.
export const FREE_MODEL = "meta/llama-3.1-8b-instruct";
export const PRO_MODEL = "meta/llama-3.1-70b-instruct";

export const PLANS: Record<Plan, PlanConfig> = {
  free: {
    id: "free",
    name: "Free",
    tagline: "Everything you need to start researching.",
    priceMonthly: 0,
    model: FREE_MODEL,
    maxSources: 5,
    dailyLimit: 5,
    features: [
      { label: "Up to 5 searches per day", included: true },
      { label: "Fast 8B answer model", included: true },
      { label: "Up to 5 cited web sources", included: true },
      { label: "Discover feed & Spaces", included: true },
      { label: "Premium 70B reasoning model", included: false },
      { label: "Deeper research (10 sources)", included: false },
      { label: "Unlimited searches", included: false },
      { label: "Priority answers", included: false },
    ],
  },
  pro: {
    id: "pro",
    name: "Pro",
    tagline: "The most powerful model and unlimited research.",
    priceMonthly: 20,
    priceId: process.env.STRIPE_PRICE_ID, // optional, for live mode
    model: PRO_MODEL,
    maxSources: 10,
    dailyLimit: null,
    features: [
      { label: "Unlimited searches", included: true },
      { label: "Premium 70B reasoning model", included: true },
      { label: "Deeper research — up to 10 sources", included: true },
      { label: "Priority answers", included: true },
      { label: "Discover feed & Spaces", included: true },
      { label: "Everything in Free", included: true },
    ],
  },
};

export function planFor(isPro: boolean): PlanConfig {
  return isPro ? PLANS.pro : PLANS.free;
}
