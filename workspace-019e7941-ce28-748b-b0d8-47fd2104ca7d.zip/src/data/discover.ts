import { DiscoverItem } from "@/lib/types";

// Gradient "images" rendered as CSS so they work offline in the preview.
export const discoverItems: DiscoverItem[] = [
  {
    id: "d1",
    category: "Tech & Science",
    title: "Room-temperature superconductor claims face fresh scrutiny",
    summary:
      "Researchers attempt to replicate a widely discussed result, with mixed outcomes. Here's what the evidence actually shows and why physicists remain cautious.",
    image: "linear-gradient(135deg,#6366f1,#8b5cf6,#ec4899)",
    source: "Nature",
    readMins: 4,
  },
  {
    id: "d2",
    category: "AI",
    title: "Open-weight models close the gap with frontier labs",
    summary:
      "A new wave of open releases matches proprietary systems on key benchmarks, reshaping how startups think about build-vs-buy decisions.",
    image: "linear-gradient(135deg,#20808D,#0ea5e9,#22d3ee)",
    source: "The Verge",
    readMins: 5,
  },
  {
    id: "d3",
    category: "Finance",
    title: "Central banks signal a slow path back to neutral rates",
    summary:
      "Markets recalibrate expectations after the latest guidance, with implications for mortgages, savings, and equity valuations.",
    image: "linear-gradient(135deg,#f59e0b,#ef4444,#b91c1c)",
    source: "Reuters",
    readMins: 3,
  },
  {
    id: "d4",
    category: "Space",
    title: "Reusable heavy-lift rockets push launch costs to new lows",
    summary:
      "An accelerating cadence of orbital flights is changing the economics of satellite constellations and deep-space missions alike.",
    image: "linear-gradient(135deg,#0f172a,#1e3a8a,#3b82f6)",
    source: "Ars Technica",
    readMins: 6,
  },
  {
    id: "d5",
    category: "Health",
    title: "What the latest sleep research means for your routine",
    summary:
      "Large cohort studies clarify the links between sleep regularity, metabolism, and long-term cognitive health.",
    image: "linear-gradient(135deg,#10b981,#14b8a6,#06b6d4)",
    source: "BBC",
    readMins: 4,
  },
  {
    id: "d6",
    category: "Culture",
    title: "Streaming bundles return as platforms chase profitability",
    summary:
      "After years of fragmentation, distributors are repackaging services—echoing the cable era they once disrupted.",
    image: "linear-gradient(135deg,#db2777,#9333ea,#4f46e5)",
    source: "Bloomberg",
    readMins: 3,
  },
  {
    id: "d7",
    category: "Tech & Science",
    title: "Quantum error correction crosses a practical threshold",
    summary:
      "Logical qubits now outlive their physical components in lab demonstrations, a milestone toward fault-tolerant computing.",
    image: "linear-gradient(135deg,#7c3aed,#2563eb,#0891b2)",
    source: "MIT Tech Review",
    readMins: 7,
  },
  {
    id: "d8",
    category: "Environment",
    title: "Grid-scale batteries reshape how cities store solar power",
    summary:
      "Falling costs make multi-hour storage viable at scale, smoothing renewable supply and cutting peak prices.",
    image: "linear-gradient(135deg,#84cc16,#22c55e,#10b981)",
    source: "Guardian",
    readMins: 5,
  },
];
