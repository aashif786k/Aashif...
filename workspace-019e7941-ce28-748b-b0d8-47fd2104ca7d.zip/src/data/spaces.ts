import { Space } from "@/lib/types";

export const defaultSpaces: Space[] = [
  {
    id: "s1",
    name: "Academic Research",
    emoji: "🎓",
    description: "Peer-reviewed sources, citations, and rigorous summaries.",
    instructions:
      "Prioritize peer-reviewed and primary sources. Always include citations and note limitations.",
    color: "#6366f1",
  },
  {
    id: "s2",
    name: "Product Strategy",
    emoji: "🚀",
    description: "Market sizing, competitor scans, and positioning notes.",
    instructions:
      "Respond as a pragmatic product strategist. Use frameworks and bullet points; quantify when possible.",
    color: "#20808D",
  },
  {
    id: "s3",
    name: "Travel Planning",
    emoji: "🌍",
    description: "Itineraries, local tips, budgets, and logistics.",
    instructions:
      "Act as a savvy travel concierge. Provide itineraries, costs, and practical local advice.",
    color: "#f59e0b",
  },
];
