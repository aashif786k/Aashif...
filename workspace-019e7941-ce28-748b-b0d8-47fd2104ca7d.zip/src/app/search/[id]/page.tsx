"use client";
import { useParams, useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { useStore, LimitError } from "@/lib/store";
import Answer from "@/components/Answer";
import SearchBox from "@/components/SearchBox";
import LimitModal from "@/components/LimitModal";
import { SearchIcon } from "@/components/icons";

export default function ThreadPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { getThread, askInThread, spaces } = useStore();
  const thread = getThread(id);
  const bottomRef = useRef<HTMLDivElement>(null);
  const [limitHit, setLimitHit] = useState(false);

  const ask = async (q: string) => {
    try {
      await askInThread(id, q);
    } catch (e) {
      if (e instanceof LimitError) setLimitHit(true);
    }
  };

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [thread?.messages.length, thread?.messages[thread.messages.length - 1]?.status]);

  if (!thread) {
    return (
      <div className="grid min-h-[60vh] place-items-center text-center px-4">
        <div>
          <p className="text-black/50 dark:text-white/50">This thread doesn’t exist or hasn’t loaded yet.</p>
          <button onClick={() => router.push("/")} className="mt-3 rounded-lg bg-brand px-4 py-2 text-sm text-white">
            Start a new search
          </button>
        </div>
      </div>
    );
  }

  const space = thread.spaceId ? spaces.find((s) => s.id === thread.spaceId) : undefined;
  const pairs: { user: string; assistant: any }[] = [];
  for (let i = 0; i < thread.messages.length; i += 2) {
    pairs.push({
      user: thread.messages[i]?.query || "",
      assistant: thread.messages[i + 1],
    });
  }

  return (
    <div className="relative mx-auto max-w-3xl px-4 pb-40 pt-6 md:pt-10">
      {space && (
        <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-black/5 dark:bg-white/10 px-3 py-1 text-xs">
          <span>{space.emoji}</span> {space.name}
        </div>
      )}

      <div className="space-y-10">
        {pairs.map((pair, i) => (
          <div key={i} className="space-y-4">
            <h2 className="flex items-start gap-2 text-xl sm:text-2xl font-semibold tracking-tight">
              <SearchIcon width={20} height={20} className="mt-1.5 shrink-0 text-black/30 dark:text-white/30" />
              <span>{pair.user}</span>
            </h2>
            {pair.assistant && (
              <Answer
                message={pair.assistant}
                onAsk={ask}
              />
            )}
            {i < pairs.length - 1 && <hr className="border-black/5 dark:border-white/10 mt-8" />}
          </div>
        ))}
      </div>
      <div ref={bottomRef} />

      {/* Sticky follow-up input */}
      <div className="fixed bottom-0 left-0 md:left-64 right-0 z-30 px-4 pb-5 pt-3 bg-gradient-to-t from-paper via-paper/95 to-transparent dark:from-[#0e1414] dark:via-[#0e1414]/95">
        <div className="mx-auto max-w-3xl">
          <SearchBox
            onSubmit={ask}
            placeholder="Ask a follow-up…"
            showFocus={false}
          />
        </div>
      </div>

      <LimitModal open={limitHit} onClose={() => setLimitHit(false)} />
    </div>
  );
}
