"use client";
import { useEffect, useState, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";
import { useStore } from "@/lib/store";
import { Logo, CheckIcon, SparkleIcon } from "@/components/icons";

function SuccessInner() {
  const params = useSearchParams();
  const router = useRouter();
  const { setPro } = useStore();
  const [status, setStatus] = useState<"verifying" | "ok" | "fail">("verifying");

  useEffect(() => {
    const sessionId = params.get("session_id");
    const demo = params.get("demo");
    const qs = new URLSearchParams();
    if (sessionId) qs.set("session_id", sessionId);
    if (demo) qs.set("demo", demo);

    fetch(`/api/checkout/verify?${qs.toString()}`)
      .then((r) => r.json())
      .then((d) => {
        if (d.paid) {
          setPro(true);
          setStatus("ok");
        } else {
          setStatus("fail");
        }
      })
      .catch(() => setStatus("fail"));
  }, [params, setPro]);

  return (
    <div className="mx-auto flex min-h-[80vh] max-w-lg flex-col items-center justify-center px-4 text-center">
      <Logo size={48} />
      {status === "verifying" && (
        <>
          <h1 className="mt-6 text-2xl font-semibold">Confirming your subscription…</h1>
          <p className="mt-2 text-black/55 dark:text-white/55">Hang tight for a moment.</p>
        </>
      )}
      {status === "ok" && (
        <>
          <div className="mt-6 grid h-16 w-16 place-items-center rounded-full bg-brand text-white">
            <CheckIcon width={32} height={32} />
          </div>
          <h1 className="mt-5 text-2xl font-semibold flex items-center gap-2">
            Welcome to Pro <SparkleIcon className="text-brand" />
          </h1>
          <p className="mt-2 text-black/55 dark:text-white/55">
            You now have the premium reasoning model, deeper research, and unlimited searches.
          </p>
          <Link
            href="/"
            className="mt-6 rounded-xl bg-brand px-5 py-2.5 text-sm font-semibold text-white hover:bg-brand-600 transition"
          >
            Start researching
          </Link>
        </>
      )}
      {status === "fail" && (
        <>
          <h1 className="mt-6 text-2xl font-semibold">We couldn’t confirm your payment</h1>
          <p className="mt-2 text-black/55 dark:text-white/55">
            If you were charged, your Pro access will activate shortly. Otherwise, try again.
          </p>
          <button
            onClick={() => router.push("/pricing")}
            className="mt-6 rounded-xl border border-black/15 dark:border-white/20 px-5 py-2.5 text-sm font-medium hover:border-brand transition"
          >
            Back to pricing
          </button>
        </>
      )}
    </div>
  );
}

export default function UpgradeSuccessPage() {
  return (
    <Suspense fallback={<div className="p-10 text-center text-black/40">Loading…</div>}>
      <SuccessInner />
    </Suspense>
  );
}
