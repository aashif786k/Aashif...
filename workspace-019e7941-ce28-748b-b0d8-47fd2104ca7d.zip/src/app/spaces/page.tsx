"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useStore } from "@/lib/store";
import { PlusIcon, TrashIcon, ArrowRightIcon } from "@/components/icons";

const emojis = ["🎓", "🚀", "🌍", "💡", "📊", "🧪", "🎨", "💼", "🩺", "⚖️", "🍳", "🎬"];
const colors = ["#6366f1", "#20808D", "#f59e0b", "#ec4899", "#10b981", "#ef4444"];

export default function SpacesPage() {
  const router = useRouter();
  const { spaces, addSpace, deleteSpace, createThread } = useStore();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");
  const [emoji, setEmoji] = useState("💡");
  const [color, setColor] = useState("#6366f1");
  const [instr, setInstr] = useState("");

  const create = () => {
    if (!name.trim()) return;
    addSpace({ name: name.trim(), description: desc.trim(), emoji, color, instructions: instr.trim() });
    setOpen(false);
    setName(""); setDesc(""); setInstr(""); setEmoji("💡"); setColor("#6366f1");
  };

  const start = async (spaceId: string) => {
    const s = spaces.find((x) => x.id === spaceId);
    const id = await createThread(`Help me get started in ${s?.name}`, spaceId);
    router.push(`/search/${id}`);
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 md:py-10">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Spaces</h1>
          <p className="text-black/50 dark:text-white/50 text-sm mt-1">Focused workspaces with their own instructions and context.</p>
        </div>
        <button
          onClick={() => setOpen((o) => !o)}
          className="flex items-center gap-2 rounded-xl bg-brand px-4 py-2 text-sm font-medium text-white hover:bg-brand-600 transition"
        >
          <PlusIcon width={16} height={16} /> New Space
        </button>
      </div>

      {open && (
        <div className="mt-5 rounded-2xl border border-black/10 dark:border-white/15 p-5 animate-fade-in">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="text-xs font-medium text-black/60 dark:text-white/60">Name</label>
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Thesis Research"
                className="mt-1 w-full rounded-lg border border-black/10 dark:border-white/15 bg-transparent px-3 py-2 text-sm outline-none focus:border-brand" />
            </div>
            <div>
              <label className="text-xs font-medium text-black/60 dark:text-white/60">Description</label>
              <input value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="What is this space for?"
                className="mt-1 w-full rounded-lg border border-black/10 dark:border-white/15 bg-transparent px-3 py-2 text-sm outline-none focus:border-brand" />
            </div>
          </div>
          <div className="mt-4">
            <label className="text-xs font-medium text-black/60 dark:text-white/60">AI Instructions (used as system prompt)</label>
            <textarea value={instr} onChange={(e) => setInstr(e.target.value)} rows={2} placeholder="e.g. Always cite peer-reviewed sources and summarize concisely."
              className="mt-1 w-full rounded-lg border border-black/10 dark:border-white/15 bg-transparent px-3 py-2 text-sm outline-none focus:border-brand resize-none" />
          </div>
          <div className="mt-4 flex flex-wrap items-center gap-4">
            <div>
              <div className="text-xs font-medium text-black/60 dark:text-white/60 mb-1">Icon</div>
              <div className="flex gap-1 flex-wrap max-w-xs">
                {emojis.map((e) => (
                  <button key={e} onClick={() => setEmoji(e)}
                    className={`h-8 w-8 rounded-lg text-lg grid place-items-center ${emoji === e ? "bg-brand/15 ring-1 ring-brand" : "hover:bg-black/5 dark:hover:bg-white/10"}`}>{e}</button>
                ))}
              </div>
            </div>
            <div>
              <div className="text-xs font-medium text-black/60 dark:text-white/60 mb-1">Color</div>
              <div className="flex gap-1.5">
                {colors.map((c) => (
                  <button key={c} onClick={() => setColor(c)} style={{ background: c }}
                    className={`h-7 w-7 rounded-full ${color === c ? "ring-2 ring-offset-2 ring-black/40 dark:ring-offset-[#0e1414]" : ""}`} />
                ))}
              </div>
            </div>
          </div>
          <div className="mt-5 flex gap-2">
            <button onClick={create} className="rounded-lg bg-brand px-4 py-2 text-sm font-medium text-white hover:bg-brand-600">Create Space</button>
            <button onClick={() => setOpen(false)} className="rounded-lg px-4 py-2 text-sm hover:bg-black/5 dark:hover:bg-white/10">Cancel</button>
          </div>
        </div>
      )}

      <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {spaces.map((s) => (
          <div key={s.id} className="group relative flex flex-col rounded-2xl border border-black/8 dark:border-white/10 p-5 hover:shadow-md transition">
            <div className="h-11 w-11 grid place-items-center rounded-xl text-2xl mb-3" style={{ background: `${s.color}22` }}>
              {s.emoji}
            </div>
            <h3 className="font-semibold">{s.name}</h3>
            <p className="mt-1 text-sm text-black/55 dark:text-white/55 flex-1">{s.description}</p>
            <button
              onClick={() => start(s.id)}
              className="mt-4 flex items-center justify-center gap-1.5 rounded-lg border border-black/10 dark:border-white/15 py-2 text-sm font-medium hover:border-brand hover:text-brand transition"
            >
              Enter space <ArrowRightIcon width={15} height={15} />
            </button>
            <button
              onClick={() => deleteSpace(s.id)}
              className="absolute right-3 top-3 hidden group-hover:grid place-items-center h-7 w-7 rounded-lg text-black/40 hover:text-red-500 hover:bg-black/5 dark:hover:bg-white/10"
              aria-label="Delete space"
            >
              <TrashIcon width={15} height={15} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
