"use client";
import { useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { useStore } from "@/lib/store";
import { PLANS } from "@/lib/plans";
import { Logo, CheckIcon, SparkleIcon } from "@/components/icons";

function Cross() {
  return (
    <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round">
      <path d="M6 6l12 12M18 6 6 18" />
    </svg>
  );
}

function PricingInner() {
  const { isPro, setPro } = useStore();
  const params = useSearchParams();
  const canceled = params.get("canceled");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const upgrade = async () => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/checkout", { method: "POST" });
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        setError(data.error || "Could not start checkout.");
        setLoading(false);
      }
    } catch (e: any) {
      setError(e?.message || "Could not start checkout.");
      setLoading(false);
    }
  };

  const free = PLANS.free;
  const pro = PLANS.pro;

  return (
    <div className="mx-auto max-w-4xl px-4 py-10 md:py-14">
      <div className="text-center">
        <div className="flex justify-center mb-3"><Logo size={44} /></div>
        <h1 className="text-3xl sm:text-4xl font-semibold tracking-tight">Upgrade to Pro</h1>
        <p className="mt-2 text-black/55 dark:text-white/55">
          Unlock the most powerful model, deeper research, and unlimited searches.
        </p>
        {canceled && (
          <div className="mt-4 inline-block rounded-lg bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300 px-3 py-1.5 text-sm">
            Checkout canceled — no charge was made.
          </div>
        )}
      </div>

      <div className="mt-10 grid gap-5 md:grid-cols-2">
        {/* Free */}
        <div className="rounded-2xl border border-black/10 dark:border-white/15 p-6 flex flex-col">
          <div className="text-sm font-semibold text-black/60 dark:text-white/60">{free.name}</div>
          <div className="mt-2 flex items-end gap-1">
            <span className="text-4xl font-semibold tracking-tight">$0</span>
            <span className="text-black/45 dark:text-white/45 mb-1">/month</span>
          </div>
          <p className="mt-1 text-sm text-black/55 dark:text-white/55">{free.tagline}</p>
          <ul className="mt-5 space-y-2.5 flex-1">
            {free.features.map((f) => (
              <li key={f.label} className={`flex items-center gap-2.5 text-sm ${f.included ? "" : "text-black/35 dark:text-white/35"}`}>
                <span className={f.included ? "text-brand" : "text-black/25 dark:text-white/25"}>
                  {f.included ? <CheckIcon width={16} height={16} /> : <Cross />}
                </span>
                {f.label}
              </li>
            ))}
          </ul>
          <button
            disabled
            className="mt-6 rounded-xl border border-black/10 dark:border-white/15 py-2.5 text-sm font-medium text-black/50 dark:text-white/50"
          >
            {isPro ? "Included with Pro" : "Your current plan"}
          </button>
        </div>

        {/* Pro */}
        <div className="relative rounded-2xl border-2 border-brand p-6 flex flex-col shadow-lg shadow-brand/10">
          <div className="absolute -top-3 left-6 rounded-full bg-brand px-3 py-1 text-[11px] font-semibold text-white flex items-center gap-1">
            <SparkleIcon width={12} height={12} /> Most popular
          </div>
          <div className="text-sm font-semibold text-brand">{pro.name}</div>
          <div className="mt-2 flex items-end gap-1">
            <span className="text-4xl font-semibold tracking-tight">${pro.priceMonthly}</span>
            <span className="text-black/45 dark:text-white/45 mb-1">/month</span>
          </div>
          <p className="mt-1 text-sm text-black/55 dark:text-white/55">{pro.tagline}</p>
          <ul className="mt-5 space-y-2.5 flex-1">
            {pro.features.map((f) => (
              <li key={f.label} className="flex items-center gap-2.5 text-sm">
                <span className="text-brand"><CheckIcon width={16} height={16} /></span>
                {f.label}
              </li>
            ))}
          </ul>
          {isPro ? (
            <button
              onClick={() => setPro(false)}
              className="mt-6 rounded-xl border border-brand/40 py-2.5 text-sm font-medium text-brand hover:bg-brand/5 transition"
            >
              ✓ You're on Pro — manage / cancel
            </button>
          ) : (
            <button
              onClick={upgrade}
              disabled={loading}
              className="mt-6 rounded-xl bg-brand py-2.5 text-sm font-semibold text-white hover:bg-brand-600 transition disabled:opacity-60"
            >
              {loading ? "Starting checkout…" : `Upgrade to Pro — $${pro.priceMonthly}/mo`}
            </button>
          )}
          {error && <p className="mt-2 text-xs text-red-500 text-center">{error}</p>}
        </div>
      </div>

      <p className="mt-8 text-center text-xs text-black/40 dark:text-white/40">
        Secure checkout powered by Stripe. Cancel anytime. Prices in USD.
      </p>
    </div>
  );
}

export default function PricingPage() {
  return (
    <Suspense fallback={<div className="p-10 text-center text-black/40">Loading…</div>}>
      <PricingInner />
    </Suspense>
  );
}
