import { createCheckout, hasStripe } from "@/lib/stripe";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST() {
  try {
    const { url, demo } = await createCheckout();
    return Response.json({ url, demo });
  } catch (e: any) {
    return Response.json(
      { error: e?.message || "Checkout failed" },
      { status: 500 }
    );
  }
}

export async function GET() {
  return Response.json({ stripe: hasStripe() });
}
