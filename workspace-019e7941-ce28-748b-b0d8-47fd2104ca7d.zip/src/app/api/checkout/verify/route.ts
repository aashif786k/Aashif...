import { NextRequest } from "next/server";
import { verifySession, hasStripe } from "@/lib/stripe";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const sessionId = req.nextUrl.searchParams.get("session_id");
  const demo = req.nextUrl.searchParams.get("demo");

  // Demo mode: trust the demo flag.
  if (demo === "1" || !hasStripe()) {
    return Response.json({ paid: true, demo: true });
  }

  if (!sessionId) {
    return Response.json({ paid: false, error: "missing session_id" }, { status: 400 });
  }

  const paid = await verifySession(sessionId);
  return Response.json({ paid, demo: false });
}
