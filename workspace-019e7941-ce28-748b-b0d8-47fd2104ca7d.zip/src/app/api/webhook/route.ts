import { NextRequest } from "next/server";
import { getStripe } from "@/lib/stripe";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Stripe webhook endpoint. In a real deployment you'd persist the user's Pro
 * status to a database here. This demo logs verified events; client-side Pro
 * state is also set on the success page so the flow works without a DB.
 *
 * Configure in Stripe dashboard -> Webhooks -> endpoint:
 *   <your-domain>/api/webhook   (event: checkout.session.completed)
 * and set STRIPE_WEBHOOK_SECRET.
 */
export async function POST(req: NextRequest) {
  const stripe = getStripe();
  const secret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!stripe || !secret) {
    return Response.json({ received: true, mode: "demo" });
  }

  const sig = req.headers.get("stripe-signature");
  const body = await req.text();

  let event;
  try {
    event = stripe.webhooks.constructEvent(body, sig as string, secret);
  } catch (err: any) {
    return new Response(`Webhook Error: ${err.message}`, { status: 400 });
  }

  switch (event.type) {
    case "checkout.session.completed":
      // TODO: mark user as Pro in your database using event.data.object
      console.log("[stripe] checkout.session.completed", (event.data.object as any).id);
      break;
    case "customer.subscription.deleted":
      // TODO: downgrade user to Free
      console.log("[stripe] subscription deleted");
      break;
    default:
      break;
  }

  return Response.json({ received: true });
}
