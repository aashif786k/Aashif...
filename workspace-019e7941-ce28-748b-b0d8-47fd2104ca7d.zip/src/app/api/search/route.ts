import { NextRequest } from "next/server";
import { generateAnswer, hasLiveConfig, hasLLMConfig, hasSearchConfig } from "@/lib/engine";
import { Focus } from "@/lib/types";
import { planFor } from "@/lib/plans";
import { hasStripe } from "@/lib/stripe";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const query: string = (body.query || "").toString().trim();
  const focus: Focus = body.focus || "all";
  const spaceInstructions: string | undefined = body.spaceInstructions;
  const isPro: boolean = !!body.pro;

  if (!query) {
    return new Response(JSON.stringify({ error: "Missing query" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }

  // Apply tier: Pro uses the premium model and fetches more sources.
  const plan = planFor(isPro);

  const payload = await generateAnswer(query, {
    focus,
    spaceInstructions,
    model: plan.model,
    maxSources: plan.maxSources,
  });

  return new Response(JSON.stringify({ ...payload, plan: plan.id }), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });
}

export async function GET() {
  return new Response(
    JSON.stringify({
      mode: hasLiveConfig() ? "live" : "demo",
      llm: hasLLMConfig(),
      search: hasSearchConfig(),
      stripe: hasStripe(),
    }),
    { status: 200, headers: { "Content-Type": "application/json" } }
  );
}
