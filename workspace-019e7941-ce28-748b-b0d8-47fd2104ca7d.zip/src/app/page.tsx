"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useStore, LimitError } from "@/lib/store";
import SearchBox from "@/components/SearchBox";
import { Logo, SparkleIcon, CompassIcon, LayersIcon, BoltIcon } from "@/components/icons";
import { Focus } from "@/lib/types";
import Link from "next/link";
import LimitModal from "@/components/LimitModal";

const suggestions = [
  "What is retrieval-augmented generation?",
  "Explain the James Webb telescope's latest discoveries",
  "Best practices for a healthy sleep schedule",
  "How do electric car batteries get recycled?",
  "Compare TypeScript and Go for backend development",
  "What caused the 2008 financial crisis?",
];

export default function Home() {
  const router = useRouter();
  const { createThread, spaces, isPro, remaining, dailyLimit } = useStore();
  const [busy, setBusy] = useState(false);
  const [limitHit, setLimitHit] = useState(false);

  const go = async (q: string, _focus: Focus) => {
    if (busy) return;
    setBusy(true);
    try {
      const id = await createThread(q);
      router.push(`/search/${id}`);
    } catch (e) {
      setBusy(false);
      if (e instanceof LimitError) setLimitHit(true);
    }
  };

  return (
    <div className="mx-auto flex min-h-[calc(100vh-3.5rem)] md:min-h-screen max-w-3xl flex-col items-center justify-center px-4 py-10">
      <div className="mb-8 flex flex-col items-center text-center">
        <Logo size={56} />
        <h1 className="mt-4 text-3xl sm:text-4xl font-semibold tracking-tight">
          Where knowledge begins
        </h1>
        <p className="mt-2 text-black/50 dark:text-white/50 text-[15px]">
          Ask anything and get a clear answer, backed by cited sources.
        </p>
      </div>

      <div className="w-full">
        <SearchBox onSubmit={go} autoFocus big placeholder="Ask anything…" />
      </div>

      {!isPro && dailyLimit !== null && (
        <div className="mt-3 flex items-center gap-2 text-xs text-black/45 dark:text-white/45">
          <span>{remaining} of {dailyLimit} free searches left today</span>
          <Link href="/pricing" className="inline-flex items-center gap-1 text-brand font-medium hover:underline">
            <BoltIcon width={12} height={12} /> Upgrade
          </Link>
        </div>
      )}

      <LimitModal open={limitHit} onClose={() => setLimitHit(false)} />

      <div className="mt-6 flex flex-wrap justify-center gap-2">
        {suggestions.map((s) => (
          <button
            key={s}
            onClick={() => go(s, "all")}
            className="rounded-full border border-black/10 dark:border-white/15 bg-white/60 dark:bg-white/5 px-3.5 py-1.5 text-xs text-black/65 dark:text-white/65 hover:border-brand hover:text-brand transition"
          >
            {s}
          </button>
        ))}
      </div>

      <div className="mt-12 grid w-full grid-cols-1 sm:grid-cols-3 gap-3">
        <Link href="/discover" className="group rounded-2xl border border-black/8 dark:border-white/10 p-4 hover:border-brand/50 hover:shadow-sm transition">
          <CompassIcon className="text-brand mb-2" />
          <div className="font-medium text-sm">Discover</div>
          <div className="text-xs text-black/45 dark:text-white/45 mt-0.5">Trending stories, summarized</div>
        </Link>
        <Link href="/spaces" className="group rounded-2xl border border-black/8 dark:border-white/10 p-4 hover:border-brand/50 hover:shadow-sm transition">
          <LayersIcon className="text-brand mb-2" />
          <div className="font-medium text-sm">Spaces</div>
          <div className="text-xs text-black/45 dark:text-white/45 mt-0.5">{spaces.length} curated research spaces</div>
        </Link>
        <div className="rounded-2xl border border-black/8 dark:border-white/10 p-4">
          <SparkleIcon className="text-brand mb-2" />
          <div className="font-medium text-sm">Cited answers</div>
          <div className="text-xs text-black/45 dark:text-white/45 mt-0.5">Every claim links to a source</div>
        </div>
      </div>
    </div>
  );
}
