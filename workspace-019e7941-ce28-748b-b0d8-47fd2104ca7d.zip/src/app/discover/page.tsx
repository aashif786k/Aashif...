"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { discoverItems } from "@/data/discover";
import { useStore } from "@/lib/store";

const categories = ["For You", ...Array.from(new Set(discoverItems.map((d) => d.category)))];

export default function DiscoverPage() {
  const [cat, setCat] = useState("For You");
  const router = useRouter();
  const { createThread } = useStore();

  const items =
    cat === "For You" ? discoverItems : discoverItems.filter((d) => d.category === cat);

  const open = async (title: string) => {
    const id = await createThread(`Tell me more about: ${title}`);
    router.push(`/search/${id}`);
  };

  const featured = items[0];
  const rest = items.slice(1);

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 md:py-10">
      <h1 className="text-2xl font-semibold tracking-tight">Discover</h1>
      <p className="text-black/50 dark:text-white/50 text-sm mt-1">Today’s most interesting stories, summarized.</p>

      <div className="mt-5 flex gap-2 overflow-x-auto pb-1">
        {categories.map((c) => (
          <button
            key={c}
            onClick={() => setCat(c)}
            className={`whitespace-nowrap rounded-full px-3.5 py-1.5 text-sm transition ${
              cat === c
                ? "bg-brand text-white"
                : "border border-black/10 dark:border-white/15 text-black/65 dark:text-white/65 hover:border-brand"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {featured && (
        <button
          onClick={() => open(featured.title)}
          className="group mt-6 block w-full overflow-hidden rounded-2xl border border-black/8 dark:border-white/10 text-left hover:shadow-md transition"
        >
          <div className="h-48 sm:h-60 w-full" style={{ backgroundImage: featured.image }} />
          <div className="p-5">
            <div className="text-xs font-medium text-brand">{featured.category}</div>
            <h2 className="mt-1 text-xl font-semibold tracking-tight group-hover:text-brand">{featured.title}</h2>
            <p className="mt-2 text-sm text-black/60 dark:text-white/60 line-clamp-2">{featured.summary}</p>
            <div className="mt-3 text-xs text-black/40 dark:text-white/40">{featured.source} · {featured.readMins} min read</div>
          </div>
        </button>
      )}

      <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {rest.map((d) => (
          <button
            key={d.id}
            onClick={() => open(d.title)}
            className="group flex flex-col overflow-hidden rounded-2xl border border-black/8 dark:border-white/10 text-left hover:shadow-md transition"
          >
            <div className="h-32 w-full" style={{ backgroundImage: d.image }} />
            <div className="flex flex-1 flex-col p-4">
              <div className="text-[11px] font-medium text-brand">{d.category}</div>
              <h3 className="mt-1 font-semibold leading-snug group-hover:text-brand line-clamp-2">{d.title}</h3>
              <p className="mt-1.5 text-xs text-black/55 dark:text-white/55 line-clamp-3 flex-1">{d.summary}</p>
              <div className="mt-3 text-[11px] text-black/40 dark:text-white/40">{d.source} · {d.readMins} min</div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
