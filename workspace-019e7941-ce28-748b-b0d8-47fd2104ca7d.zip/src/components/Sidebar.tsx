"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { useStore } from "@/lib/store";
import {
  Logo, SearchIcon, CompassIcon, LayersIcon, PlusIcon, SunIcon, MoonIcon,
  TrashIcon, MenuIcon, CrownIcon, BoltIcon,
} from "./icons";

const nav = [
  { href: "/", label: "Home", icon: SearchIcon },
  { href: "/discover", label: "Discover", icon: CompassIcon },
  { href: "/spaces", label: "Spaces", icon: LayersIcon },
];

export default function Sidebar() {
  const path = usePathname();
  const {
    threads, theme, toggleTheme, deleteThread, mode, llmLive, searchLive,
    isPro, remaining, dailyLimit,
  } = useStore();
  const [open, setOpen] = useState(false);

  const recent = [...threads].sort((a, b) => b.updatedAt - a.updatedAt).slice(0, 8);

  return (
    <>
      {/* Mobile top bar */}
      <div className="md:hidden sticky top-0 z-40 flex items-center justify-between px-4 h-14 border-b border-black/5 dark:border-white/10 bg-paper/90 dark:bg-[#0e1414]/90 backdrop-blur">
        <Link href="/" className="flex items-center gap-2"><Logo size={26} /><span className="font-semibold">Perplexa</span></Link>
        <button onClick={() => setOpen((o) => !o)} className="p-2 rounded-lg hover:bg-black/5 dark:hover:bg-white/10">
          <MenuIcon />
        </button>
      </div>

      <aside
        className={`${open ? "block" : "hidden"} md:flex fixed md:sticky top-0 z-40 md:z-auto h-screen w-64 shrink-0 flex-col border-r border-black/5 dark:border-white/10 bg-paper dark:bg-[#0e1414] px-3 py-4`}
      >
        <Link href="/" className="flex items-center gap-2.5 px-2 mb-5" onClick={() => setOpen(false)}>
          <Logo />
          <div>
            <div className="font-semibold tracking-tight leading-none">Perplexa</div>
            <div className="text-[10px] text-black/40 dark:text-white/40 mt-0.5">answers, with sources</div>
          </div>
        </Link>

        <Link
          href="/"
          onClick={() => setOpen(false)}
          className="flex items-center gap-2 mb-4 rounded-xl border border-black/10 dark:border-white/15 px-3 py-2.5 text-sm font-medium hover:border-brand hover:text-brand transition"
        >
          <PlusIcon width={16} height={16} /> New Thread
        </Link>

        <nav className="space-y-1">
          {nav.map((n) => {
            const active = path === n.href;
            const Icon = n.icon;
            return (
              <Link
                key={n.href}
                href={n.href}
                onClick={() => setOpen(false)}
                className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition ${
                  active
                    ? "bg-brand/12 text-brand font-medium"
                    : "text-black/70 dark:text-white/70 hover:bg-black/5 dark:hover:bg-white/10"
                }`}
              >
                <Icon width={18} height={18} /> {n.label}
              </Link>
            );
          })}
        </nav>

        <div className="mt-6 flex-1 overflow-y-auto">
          <div className="px-3 text-[11px] font-semibold uppercase tracking-wider text-black/40 dark:text-white/40 mb-1">
            Recent
          </div>
          {recent.length === 0 && (
            <div className="px-3 text-xs text-black/40 dark:text-white/40 py-2">No threads yet</div>
          )}
          <ul className="space-y-0.5">
            {recent.map((t) => {
              const active = path === `/search/${t.id}`;
              return (
                <li key={t.id} className="group relative">
                  <Link
                    href={`/search/${t.id}`}
                    onClick={() => setOpen(false)}
                    className={`block truncate rounded-lg px-3 py-1.5 pr-8 text-sm transition ${
                      active
                        ? "bg-black/5 dark:bg-white/10 font-medium"
                        : "text-black/65 dark:text-white/65 hover:bg-black/5 dark:hover:bg-white/10"
                    }`}
                    title={t.title}
                  >
                    {t.title}
                  </Link>
                  <button
                    onClick={(e) => { e.preventDefault(); deleteThread(t.id); }}
                    className="absolute right-1.5 top-1.5 hidden group-hover:block p-1 rounded text-black/40 hover:text-red-500 dark:text-white/40"
                    aria-label="Delete thread"
                  >
                    <TrashIcon width={14} height={14} />
                  </button>
                </li>
              );
            })}
          </ul>
        </div>

        {/* Plan / upgrade */}
        <div className="mt-3">
          {isPro ? (
            <Link
              href="/pricing"
              onClick={() => setOpen(false)}
              className="flex items-center gap-2 rounded-xl border border-brand/40 bg-brand/8 px-3 py-2.5 text-sm font-medium text-brand hover:bg-brand/12 transition"
            >
              <CrownIcon width={17} height={17} /> Pro plan
              <span className="ml-auto rounded-full bg-brand text-white text-[10px] px-2 py-0.5">active</span>
            </Link>
          ) : (
            <Link
              href="/pricing"
              onClick={() => setOpen(false)}
              className="block rounded-xl border border-brand/30 bg-gradient-to-br from-brand/10 to-brand/5 p-3 hover:border-brand transition"
            >
              <div className="flex items-center gap-2 text-sm font-semibold text-brand">
                <BoltIcon width={16} height={16} /> Upgrade to Pro
              </div>
              <div className="mt-1 text-[11px] text-black/55 dark:text-white/55 leading-snug">
                Premium model, deeper research & unlimited searches.
              </div>
              {dailyLimit !== null && (
                <div className="mt-2 text-[11px] text-black/45 dark:text-white/45">
                  {remaining} of {dailyLimit} free searches left today
                </div>
              )}
            </Link>
          )}
        </div>

        <div className="mt-3 pt-3 border-t border-black/5 dark:border-white/10 space-y-2">
          <div className="flex items-center gap-2 px-2" title={`AI: ${llmLive ? "live" : "demo"} · Web search: ${searchLive ? "live" : "demo"}`}>
            <span
              className={`h-2 w-2 rounded-full ${
                llmLive && searchLive ? "bg-green-500" : llmLive ? "bg-emerald-400" : "bg-amber-500"
              }`}
            />
            <span className="text-xs text-black/50 dark:text-white/50">
              {llmLive && searchLive
                ? "Live · NVIDIA + web"
                : llmLive
                ? "Live AI · NVIDIA"
                : mode === "unknown"
                ? "Connecting…"
                : "Demo mode"}
            </span>
          </div>
          <button
            onClick={toggleTheme}
            className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm text-black/70 dark:text-white/70 hover:bg-black/5 dark:hover:bg-white/10 transition"
          >
            {theme === "light" ? <MoonIcon width={18} height={18} /> : <SunIcon width={18} height={18} />}
            {theme === "light" ? "Dark mode" : "Light mode"}
          </button>
        </div>
      </aside>
    </>
  );
}
