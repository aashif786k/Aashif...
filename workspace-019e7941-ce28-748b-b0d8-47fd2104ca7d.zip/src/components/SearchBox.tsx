"use client";
import { useState, useRef, useEffect } from "react";
import { Focus } from "@/lib/types";
import { ArrowUpIcon, GlobeIcon, BookIcon, PenIcon, VideoIcon, UsersIcon, ChartIcon } from "./icons";

const focuses: { id: Focus; label: string; icon: any }[] = [
  { id: "all", label: "All", icon: GlobeIcon },
  { id: "academic", label: "Academic", icon: BookIcon },
  { id: "writing", label: "Writing", icon: PenIcon },
  { id: "video", label: "Video", icon: VideoIcon },
  { id: "social", label: "Social", icon: UsersIcon },
  { id: "finance", label: "Finance", icon: ChartIcon },
];

export default function SearchBox({
  onSubmit,
  autoFocus = false,
  placeholder = "Ask anything…",
  big = false,
  showFocus = true,
}: {
  onSubmit: (q: string, focus: Focus) => void;
  autoFocus?: boolean;
  placeholder?: string;
  big?: boolean;
  showFocus?: boolean;
}) {
  const [value, setValue] = useState("");
  const [focus, setFocus] = useState<Focus>("all");
  const ref = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (autoFocus) ref.current?.focus();
  }, [autoFocus]);

  const submit = () => {
    const q = value.trim();
    if (!q) return;
    onSubmit(q, focus);
    setValue("");
  };

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submit();
    }
  };

  return (
    <div
      className={`w-full rounded-2xl border border-black/10 dark:border-white/15 bg-white dark:bg-[#161c1c] shadow-sm focus-within:border-brand focus-within:shadow-md transition ${
        big ? "p-3" : "p-2.5"
      }`}
    >
      <textarea
        ref={ref}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={onKey}
        rows={big ? 2 : 1}
        placeholder={placeholder}
        className="w-full resize-none bg-transparent px-2 pt-1 text-[15px] outline-none placeholder:text-black/40 dark:placeholder:text-white/40"
      />
      <div className="flex items-center justify-between gap-2 px-1 pt-1">
        {showFocus ? (
          <div className="flex items-center gap-1 overflow-x-auto">
            {focuses.map((f) => {
              const Icon = f.icon;
              const active = focus === f.id;
              return (
                <button
                  key={f.id}
                  onClick={() => setFocus(f.id)}
                  className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium whitespace-nowrap transition ${
                    active
                      ? "bg-brand/12 text-brand"
                      : "text-black/55 dark:text-white/55 hover:bg-black/5 dark:hover:bg-white/10"
                  }`}
                >
                  <Icon width={15} height={15} /> {f.label}
                </button>
              );
            })}
          </div>
        ) : (
          <span />
        )}
        <button
          onClick={submit}
          disabled={!value.trim()}
          className="shrink-0 grid place-items-center h-9 w-9 rounded-xl bg-brand text-white disabled:opacity-30 disabled:cursor-not-allowed hover:bg-brand-600 transition"
          aria-label="Send"
        >
          <ArrowUpIcon width={18} height={18} />
        </button>
      </div>
    </div>
  );
}
