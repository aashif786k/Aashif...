"use client";
import Link from "next/link";
import { BoltIcon, SparkleIcon, CheckIcon } from "./icons";
import { PLANS } from "@/lib/plans";

export default function LimitModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  if (!open) return null;
  const pro = PLANS.pro;
  return (
    <div
      className="fixed inset-0 z-50 grid place-items-center bg-black/40 backdrop-blur-sm p-4 animate-fade-in"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-2xl bg-white dark:bg-[#161c1c] p-6 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="grid h-12 w-12 place-items-center rounded-xl bg-brand/12 text-brand">
          <BoltIcon width={24} height={24} />
        </div>
        <h2 className="mt-4 text-xl font-semibold tracking-tight">You’ve hit today’s free limit</h2>
        <p className="mt-1.5 text-sm text-black/55 dark:text-white/55">
          Free includes {PLANS.free.dailyLimit} searches per day. Upgrade to Pro for unlimited
          searches and our most powerful model.
        </p>
        <ul className="mt-4 space-y-2">
          {pro.features.slice(0, 4).map((f) => (
            <li key={f.label} className="flex items-center gap-2.5 text-sm">
              <span className="text-brand"><CheckIcon width={16} height={16} /></span>
              {f.label}
            </li>
          ))}
        </ul>
        <div className="mt-6 flex gap-2">
          <Link
            href="/pricing"
            className="flex-1 rounded-xl bg-brand py-2.5 text-center text-sm font-semibold text-white hover:bg-brand-600 transition flex items-center justify-center gap-1.5"
          >
            <SparkleIcon width={15} height={15} /> Upgrade to Pro
          </Link>
          <button
            onClick={onClose}
            className="rounded-xl border border-black/10 dark:border-white/15 px-4 py-2.5 text-sm hover:bg-black/5 dark:hover:bg-white/10 transition"
          >
            Maybe later
          </button>
        </div>
      </div>
    </div>
  );
}
