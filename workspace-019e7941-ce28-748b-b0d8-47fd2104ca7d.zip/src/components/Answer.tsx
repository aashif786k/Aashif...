"use client";
import { useState } from "react";
import { Message, Source } from "@/lib/types";
import { renderMarkdown } from "@/lib/markdown";
import { SparkleIcon, CopyIcon, CheckIcon, ShareIcon, GlobeIcon, ArrowRightIcon } from "./icons";

function SourceChip({ s }: { s: Source }) {
  return (
    <a
      href={s.url}
      target="_blank"
      rel="noreferrer"
      className="group flex flex-col justify-between rounded-xl border border-black/8 dark:border-white/10 bg-white dark:bg-[#161c1c] p-3 hover:border-brand/50 hover:shadow-sm transition min-w-0"
    >
      <div className="text-xs font-medium line-clamp-2 leading-snug mb-2 group-hover:text-brand">
        {s.title}
      </div>
      <div className="flex items-center gap-1.5 text-[11px] text-black/45 dark:text-white/45">
        <span className="grid place-items-center h-4 w-4 rounded bg-brand/10 text-brand text-[9px] font-bold">
          {s.id}
        </span>
        <span className="truncate">{s.domain}</span>
      </div>
    </a>
  );
}

function StatusLine({ status }: { status: NonNullable<Message["status"]> }) {
  const steps: { key: string; label: string }[] = [
    { key: "searching", label: "Searching the web" },
    { key: "reading", label: "Reading sources" },
    { key: "writing", label: "Writing answer" },
  ];
  const order = ["thinking", "searching", "reading", "writing", "done"];
  const cur = order.indexOf(status || "thinking");

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 text-sm text-brand font-medium">
        <SparkleIcon width={16} height={16} className="animate-pulse-soft" />
        {steps.find((s) => s.key === status)?.label || "Thinking…"}
      </div>
      <div className="space-y-2">
        {steps.map((s) => {
          const idx = order.indexOf(s.key);
          const done = cur > idx;
          const active = cur === idx;
          return (
            <div key={s.key} className="flex items-center gap-2 text-xs">
              <span
                className={`h-3.5 w-3.5 rounded-full grid place-items-center ${
                  done ? "bg-brand text-white" : active ? "border-2 border-brand animate-pulse" : "border border-black/20 dark:border-white/20"
                }`}
              >
                {done && <CheckIcon width={9} height={9} />}
              </span>
              <span className={done || active ? "text-black/70 dark:text-white/70" : "text-black/35 dark:text-white/35"}>
                {s.label}
              </span>
            </div>
          );
        })}
      </div>
      <div className="space-y-2 pt-2">
        <div className="skeleton h-3 w-full" />
        <div className="skeleton h-3 w-[92%]" />
        <div className="skeleton h-3 w-[78%]" />
      </div>
    </div>
  );
}

export default function Answer({
  message,
  onAsk,
}: {
  message: Message;
  onAsk?: (q: string) => void;
}) {
  const [copied, setCopied] = useState(false);
  const p = message.payload;

  if (message.status && message.status !== "done" && message.status !== "error") {
    return (
      <div className="animate-fade-in">
        <StatusLine status={message.status} />
      </div>
    );
  }

  if (message.status === "error") {
    return (
      <div className="rounded-xl border border-red-300 bg-red-50 dark:bg-red-950/30 p-4 text-sm text-red-700 dark:text-red-300">
        ⚠️ {message.error || "Something went wrong."}
      </div>
    );
  }

  if (!p) return null;

  const copy = () => {
    navigator.clipboard?.writeText(p.answer.replace(/\[\d+\]/g, ""));
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="animate-fade-in space-y-6">
      {/* Sources */}
      <div>
        <div className="flex items-center gap-2 text-sm font-semibold mb-3">
          <GlobeIcon width={17} height={17} className="text-brand" />
          Sources
          <span className="text-xs font-normal text-black/40 dark:text-white/40">· {p.sources.length}</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
          {p.sources.map((s) => (
            <SourceChip key={s.id} s={s} />
          ))}
        </div>
      </div>

      {/* Answer */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <SparkleIcon width={17} height={17} className="text-brand" />
            Answer
            {p.mode === "demo" && (
              <span className="rounded-full bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300 px-2 py-0.5 text-[10px] font-medium">
                demo
              </span>
            )}
            {p.plan === "pro" && (
              <span className="rounded-full bg-brand/15 text-brand px-2 py-0.5 text-[10px] font-semibold">
                PRO
              </span>
            )}
          </div>
          <div className="flex items-center gap-1">
            <button onClick={copy} className="flex items-center gap-1 rounded-lg px-2 py-1.5 text-xs text-black/55 dark:text-white/55 hover:bg-black/5 dark:hover:bg-white/10 transition">
              {copied ? <CheckIcon width={14} height={14} /> : <CopyIcon width={14} height={14} />}
              {copied ? "Copied" : "Copy"}
            </button>
            <button className="flex items-center gap-1 rounded-lg px-2 py-1.5 text-xs text-black/55 dark:text-white/55 hover:bg-black/5 dark:hover:bg-white/10 transition">
              <ShareIcon width={14} height={14} /> Share
            </button>
          </div>
        </div>
        <div className="prose-answer text-black/85 dark:text-white/85">
          {renderMarkdown(p.answer, p.sources)}
        </div>
      </div>

      {/* Related */}
      {p.related.length > 0 && onAsk && (
        <div className="pt-2 border-t border-black/5 dark:border-white/10">
          <div className="text-sm font-semibold mb-2 flex items-center gap-2">
            <ArrowRightIcon width={16} height={16} className="text-brand" /> Related
          </div>
          <div className="divide-y divide-black/5 dark:divide-white/10">
            {p.related.map((r, i) => (
              <button
                key={i}
                onClick={() => onAsk(r)}
                className="flex w-full items-center justify-between gap-3 py-2.5 text-left text-sm hover:text-brand transition group"
              >
                <span>{r}</span>
                <span className="text-black/30 dark:text-white/30 group-hover:text-brand">
                  <ArrowRightIcon width={16} height={16} />
                </span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
