# Perplexa 🔎

A **Perplexity-style AI answer engine** built with Next.js 14 (App Router), React, TypeScript, and Tailwind CSS.

It works **out of the box in demo mode** (no keys needed) and switches to **real, live web answers** the moment you add API keys.

![mode badge](https://img.shields.io/badge/mode-demo%20%2F%20live-20808D)

---

## ✨ Features

- **Cited answers** — every answer renders with numbered `[1]` citation pills that link to sources.
- **Source rail** — top web sources shown as clickable cards above each answer.
- **Conversational threads** — ask follow-up questions; full thread is preserved.
- **Suggested follow-ups ("Related")** — one-click deeper exploration.
- **Search history** — recent threads in the sidebar, persisted in `localStorage`.
- **Discover feed** — a categorized feed of trending stories; click to research any of them.
- **Spaces** — create focused workspaces with custom AI instructions (used as the system prompt).
- **Focus modes** — All / Academic / Writing / Video / Social / Finance.
- **Dark mode** — toggle in the sidebar, remembered across sessions.
- **Staged "thinking" UI** — searching → reading → writing, with skeleton loaders.
- **Provider-agnostic backend** — swap in OpenAI/Anthropic + Tavily/Serper/Brave.

---

## 🚀 Getting started

```bash
npm install
npm run dev
# open http://localhost:3000
```

That's it — the app runs immediately in **demo mode** with realistic mock answers and sources.

---

## 🔌 Enabling LIVE answers (real web + LLM)

1. Copy the example env file:
   ```bash
   cp .env.local.example .env.local
   ```
2. Fill in **one LLM provider** and (optionally) **one search provider**:
   ```env
   # --- LLM (pick one) ---
   # NVIDIA NIM (OpenAI-compatible) -> https://build.nvidia.com
   LLM_PROVIDER=nvidia
   NVIDIA_API_KEY=nvapi-...
   NVIDIA_MODEL=qwen/qwen3-next-80b-a3b-instruct

   # or OpenAI
   # OPENAI_API_KEY=sk-...
   # OPENAI_MODEL=gpt-4o-mini

   # or Anthropic
   # ANTHROPIC_API_KEY=sk-ant-...

   # --- Web search (pick one, optional) ---
   # SERPER_API_KEY=...   (Google via serper.dev)
   # TAVILY_API_KEY=tvly-...
   # BRAVE_API_KEY=...
   ```
3. Restart `npm run dev`.

### Status badge (sidebar)
| Keys present | Badge | Behavior |
|---|---|---|
| LLM **+** search | 🟢 **Live · NVIDIA + web** | Real web results + real AI answer with true citations |
| LLM only | 🟩 **Live AI · NVIDIA** | Real AI answers; source cards are placeholders until you add a search key |
| none | 🟡 **Demo mode** | Fully simulated answers |

If a live call fails, it gracefully falls back to demo so the UI never breaks.

### NVIDIA models
Any model from the NVIDIA catalog works (set `NVIDIA_MODEL`). Examples that are available on the cloud endpoint:
`qwen/qwen3-next-80b-a3b-instruct`, `meta/llama-3.1-70b-instruct`, `meta/llama-3.1-8b-instruct`, `nvidia/llama-3.1-nemotron-70b-instruct`.
List all available models:
```bash
curl https://integrate.api.nvidia.com/v1/models -H "Authorization: Bearer $NVIDIA_API_KEY"
```

---

## 💎 Premium (Pro plan + Stripe)

Perplexa has a **Free** and **Pro** tier with real Stripe Checkout, and a
**simulated checkout fallback** so the whole upgrade flow works with zero setup.

| | Free | Pro ($20/mo) |
|---|---|---|
| AI model | Llama 3.1 **8B** | Llama 3.1 **70B** |
| Web sources / query | 5 | 10 |
| Daily searches | 5 | Unlimited |
| Discover & Spaces | ✓ | ✓ |

**Flow:** `Upgrade` (sidebar / `/pricing`) → `POST /api/checkout` →
Stripe Checkout (or `/upgrade/success?demo=1` in demo mode) →
`/api/checkout/verify` confirms payment → client is marked Pro (persisted in
`localStorage`). Pro state sends `pro:true` to `/api/search`, which selects the
premium model and fetches more sources. Free users are limited to 5 searches/day
and shown an upgrade modal when they hit the cap.

### Enable real payments
Add to `.env.local` and restart:
```env
STRIPE_SECRET_KEY=sk_test_...
# STRIPE_PRICE_ID=price_...          # optional recurring Price for Pro
# STRIPE_WEBHOOK_SECRET=whsec_...    # for /api/webhook verification
NEXT_PUBLIC_BASE_URL=http://localhost:3000
```
Without `STRIPE_SECRET_KEY`, checkout is simulated (no charge) so you can test
the entire upgrade → Pro experience. The sidebar shows your plan and remaining
free searches.

### Premium endpoints
- `POST /api/checkout` → creates a Checkout session (or demo URL)
- `GET  /api/checkout/verify?session_id=…` → confirms payment & unlocks Pro
- `POST /api/webhook` → Stripe webhook (`checkout.session.completed`, etc.)

> In production, persist Pro status to a database in the webhook handler. This
> demo stores it client-side for simplicity.

---

## 🧱 Architecture

```
src/
├─ app/
│  ├─ layout.tsx            # shell + sidebar + store provider
│  ├─ page.tsx              # home / landing search
│  ├─ search/[id]/page.tsx  # thread view (Q&A + follow-ups)
│  ├─ discover/page.tsx     # discover feed
│  ├─ spaces/page.tsx       # spaces CRUD
│  ├─ pricing/page.tsx      # Free vs Pro pricing + upgrade
│  ├─ upgrade/success/...   # post-checkout verification → unlock Pro
│  └─ api/
│     ├─ search/route.ts    # POST answer endpoint (tier-aware), GET status
│     ├─ checkout/route.ts  # create Stripe Checkout (or demo URL)
│     ├─ checkout/verify/.. # verify a completed session
│     └─ webhook/route.ts   # Stripe webhook
├─ components/              # Sidebar, SearchBox, Answer, LimitModal, icons
├─ lib/
│  ├─ engine.ts             # provider-agnostic search + LLM orchestration
│  ├─ plans.ts              # Free/Pro tiers, models, limits
│  ├─ stripe.ts             # Stripe wrapper w/ demo fallback
│  ├─ store.tsx             # React context: threads, spaces, theme, Pro, usage
│  ├─ markdown.tsx          # tiny dependency-free markdown + citations
│  └─ types.ts
└─ data/                    # demo discover items + default spaces
```

### How answers are generated
`lib/engine.ts` → `generateAnswer()`:
1. If live keys exist → `webSearch()` (Tavily/Serper/Brave) → `llmAnswer()` (OpenAI/Anthropic) with a strict "cite your sources" system prompt.
2. Otherwise → demo generator produces a structured, cited answer with realistic source cards.

---

## 🛠 Tech
Next.js 14 · React 18 · TypeScript · Tailwind CSS · zero runtime UI dependencies.

## 📦 Scripts
- `npm run dev` – dev server
- `npm run build` – production build
- `npm start` – run production build
